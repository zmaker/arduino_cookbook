#ifndef MY_LIBRARY_H
#define MY_LIBRARY_H

#include <Arduino.h>

int attiva(int pin);
int accendi(int pin);
int spegni(int pin);

#endif
