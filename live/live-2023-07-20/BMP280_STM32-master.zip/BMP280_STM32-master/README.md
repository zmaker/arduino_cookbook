# BMP280_STM32
Simply driver Bosh sensors BMP280/BME280 for STM32 microcontroler using HAL.

It's modifity driver from here: https://github.com/SuperHouse/esp-open-rtos/tree/master/extras/bmp280

