# Example_BMP280

Example project with BMP280 and STM32f0DISCOVERY

Project generated in CubeMX for Atollic TrueStudio

SDA --> PB7
SCL --> PB6

UART RX --> PA10
UART TX --> PA9

