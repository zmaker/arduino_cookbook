Tone library for ESP32
