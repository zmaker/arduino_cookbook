#include "Arduino.h"
#include "../../examples/override_putchar/override_putchar.ino"
