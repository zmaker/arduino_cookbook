#include "Arduino.h"
#include "../../examples/specify_print_class/specify_print_class.ino"
