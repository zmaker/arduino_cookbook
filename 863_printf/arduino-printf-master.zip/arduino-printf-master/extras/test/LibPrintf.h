#define PRINTF_ALIAS_STANDARD_FUNCTION_NAMES 1
#include "printf.h"
