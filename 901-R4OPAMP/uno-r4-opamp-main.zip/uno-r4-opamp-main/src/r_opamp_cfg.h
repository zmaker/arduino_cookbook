#pragma once

#define OPAMP_CFG_PARAM_CHECKING_ENABLE 0